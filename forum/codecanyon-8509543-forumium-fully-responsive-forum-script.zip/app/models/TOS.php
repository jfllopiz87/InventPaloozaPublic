<?php

class TOS extends Eloquent
{

    public $timestamps = false;
    protected $table = 't_tos';
    protected $fillable = array('tos');

}
