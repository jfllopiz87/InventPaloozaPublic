{{Lang::get('messages.your_new_password_is')}}: {{$newpass}} <br>
{{Lang::get('messages.you_can_login_here')}}: {{$login}}<br>
