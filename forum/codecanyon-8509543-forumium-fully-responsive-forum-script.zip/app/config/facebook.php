<?php

include(base_path() . "/conf.php");
return array(
    'appId' => $fb_appId,
    'secret' => $fb_secret
);
