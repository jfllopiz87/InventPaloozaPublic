<?php
//The URL of your applicaiton. You must redirect your domain to the public folder of the script. If your folder is forumpro you need to reidrect to forumpro/public
$conf_site_url = "http://localhost";
//Database configuration
$db_host = "localhost";
$db_username= "";
$db_password = "";
$db_name = "";
//Facebook API configuration
$fb_appId = "";
$fb_secret = "";
//SMTP Mail configuration
$smtp_host = "smtp.gmail.com"; // smtp.gmail.com is google's SMTP server you can add the address of your 
$smtp_username = ""; // if the $smtp_host is smtp.gmail.com the username must be your google+/gmail account
$smtp_password = ""; // the password of smtp_username
$smtp_port = 587; // The default port is 465 you can reconfigure it
?>
